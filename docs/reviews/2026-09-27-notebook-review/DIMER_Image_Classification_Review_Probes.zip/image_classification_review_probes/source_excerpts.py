"""Source-excerpt probes, transcribed from the pinned notebook source.
Repository: kurtvalcorza/vit-classification-pipeline
Commit: c92326be7b2754e7c00cf5cdb1c9a402cb3f16c7
Source: tools/multimodel_image_classification_workshop_source.py
These are excerpts, not a downloaded/full notebook. Imports are harness setup.
"""
import csv, hashlib, random, shutil, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image, ImageOps
MAX_IMAGE_SIDE = 4096

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def decoded_pixel_digest(path):
    with Image.open(path) as image:
        rgb = ImageOps.exif_transpose(image).convert("RGB")
        payload = f"{rgb.size[0]}x{rgb.size[1]}:".encode() + rgb.tobytes()
    return hashlib.sha256(payload).hexdigest()

def validate_image(path):
    with Image.open(path) as image:
        image.load()
        image = ImageOps.exif_transpose(image).convert("RGB")
        if not (1 <= image.width <= MAX_IMAGE_SIDE and 1 <= image.height <= MAX_IMAGE_SIDE):
            raise ValueError(f"{path.name}: unsupported image size {image.size}")
        return image.size

def safe_extract_byod_zip(zip_path, destination):
    destination = destination.resolve()
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as archive:
        infos = archive.infolist()
        total = sum(info.file_size for info in infos)
        if total > 2 * 1024**3:
            raise ValueError("BYOD ZIP expanded size exceeds 2 GiB")
        for info in infos:
            name = Path(info.filename)
            if name.is_absolute() or ".." in name.parts:
                raise ValueError(f"unsafe ZIP path: {info.filename}")
            mode = info.external_attr >> 16
            if mode and (mode & 0o170000) == 0o120000:
                raise ValueError(f"symlink ZIP member refused: {info.filename}")
            target = (destination / name).resolve()
            if destination not in target.parents and target != destination:
                raise ValueError(f"ZIP path escapes extraction root: {info.filename}")
        archive.extractall(destination)
    return destination

def load_byod(path):
    source = Path(path)
    if source.is_file() and source.suffix.lower() == ".zip":
        root = safe_extract_byod_zip(source, WORK_ROOT / "images" / "byod")
    elif source.is_dir():
        root = source
    else:
        raise ValueError("BYOD_PATH must be a directory or ZIP")
    labels = root / "labels.csv"
    if not labels.is_file():
        candidates = list(root.glob("*/labels.csv"))
        if len(candidates) == 1:
            labels = candidates[0]
            root = labels.parent
        else:
            raise ValueError("BYOD dataset must contain labels.csv")
    rows = list(csv.DictReader(labels.read_text(encoding="utf-8").splitlines()))
    required = {"id", "file", "label"}
    if not rows or not required <= set(rows[0]):
        raise ValueError(f"labels.csv must contain columns {sorted(required)}")
    if len({row["id"] for row in rows}) != len(rows):
        raise ValueError("BYOD ids must be unique")
    records = []
    for row in rows:
        if not row["id"] or not row["label"]:
            raise ValueError("BYOD id and label must be non-empty")
        image_path = (root / row["file"]).resolve()
        if root.resolve() not in image_path.parents:
            raise ValueError(f"image path escapes dataset root: {row['file']}")
        if not image_path.is_file():
            raise ValueError(f"missing BYOD image: {row['file']}")
        validate_image(image_path)
        records.append({"source_id": row["id"], "label": row["label"],
            "observer": row.get("observer", ""), "path": str(image_path),
            "bytes": image_path.stat().st_size, "sha256": sha256_file(image_path)})
    labels_present = sorted({r["label"] for r in records})
    if not 2 <= len(labels_present) <= 100:
        raise ValueError("BYOD requires 2..100 classes")
    return records

def exact_builtin_split(records, seed=42):
    rng = random.Random(seed)
    by_label = {}
    for record in records:
        by_label.setdefault(record["label"], []).append(dict(record))
    out = {"train": [], "validation": [], "test": []}
    sizes = {"train": 18, "validation": 4, "test": 8}
    for label in sorted(by_label):
        pool = by_label[label]
        rng.shuffle(pool)
        cursor = 0
        for split, per_class in sizes.items():
            out[split].extend(pool[cursor:cursor + per_class])
            cursor += per_class
    for split in out:
        rng.shuffle(out[split])
        out[split] = [{**record, "id": f"{split}-{i:03d}", "split": split}
                      for i, record in enumerate(out[split])]
    return out

def stratified_byod_split(records, seed=42):
    rng = random.Random(seed)
    by_label = {}
    for r in records:
        by_label.setdefault(r["label"], []).append(dict(r))
    out = {"train": [], "validation": [], "test": []}
    for label in sorted(by_label):
        pool = by_label[label]
        rng.shuffle(pool)
        n = len(pool)
        if n < 8:
            raise ValueError(f"{label}: at least 8 images are required for the automatic split")
        n_test = max(1, round(n * 0.25))
        n_val = max(1, round(n * 0.15))
        if n - n_test - n_val < 2:
            raise ValueError(f"{label}: too few training images after split")
        n_train = n - n_val - n_test
        out["train"].extend(pool[:n_train])
        out["validation"].extend(pool[n_train:n_train+n_val])
        out["test"].extend(pool[n_train+n_val:])
    for split in out:
        rng.shuffle(out[split])
        out[split] = [{**r, "id": f"{split}-{i:03d}", "split": split}
                      for i, r in enumerate(out[split])]
    return out

def basic_classification_metrics(y_true, y_pred, classes):
    classes = list(classes)
    index = {c: i for i, c in enumerate(classes)}
    cm = np.zeros((len(classes), len(classes)), dtype=int)
    for truth, pred in zip(y_true, y_pred):
        cm[index[truth], index[pred]] += 1
    per_class = []
    f1s = []
    for i, label in enumerate(classes):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        f1s.append(f1)
        per_class.append({"class": label, "precision": precision, "recall": recall,
                          "f1": f1, "support": int(cm[i, :].sum())})
    return {"accuracy": float(np.trace(cm) / cm.sum()), "macro_f1": float(np.mean(f1s)),
            "confusion": cm, "per_class": per_class}

def evaluate_prediction_csv(path, classes):
    pred=pd.read_csv(path)
    metrics=basic_classification_metrics(pred["truth"],pred["prediction"],classes)
    eps=1e-12
    class_to_idx={c:i for i,c in enumerate(classes)}
    probs=pred[[f"prob_{c}" for c in classes]].to_numpy(dtype=float)
    y=np.asarray([class_to_idx[x] for x in pred["truth"]],dtype=int)
    log_loss=float(-np.mean(np.log(np.clip(probs[np.arange(len(y)),y],eps,1.0))))
    metrics["log_loss"]=log_loss
    return pred,metrics
