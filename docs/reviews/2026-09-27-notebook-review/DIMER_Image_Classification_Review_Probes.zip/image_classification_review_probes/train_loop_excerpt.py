"""Transcribed training/selection/serialization loop from PROBE_TRAIN_RUNNER.
Harness wraps the original loop as a function on a synthetic feature fixture.
No pretrained vision model or image feature extractor is run.
"""
import json, math
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from safetensors.torch import save_file, load_file

def softmax_probs(head,x):
    with torch.inference_mode():
        return torch.softmax(head(x),dim=1).cpu().numpy()

def run(features_path, artifact, steps=1000, lr=0.001, weight_decay=0.0001, seed=0):
    args=SimpleNamespace(steps=steps,lr=lr,weight_decay=weight_decay,seed=seed)
    data=np.load(features_path,allow_pickle=False)
    X=data['features'].astype(np.float32)
    ids=data['ids'].astype(str); labels=data['labels'].astype(str); splits=data['splits'].astype(str)
    classes=sorted(set(labels.tolist()))
    class_to_idx={c:i for i,c in enumerate(classes)}
    y=np.asarray([class_to_idx[x] for x in labels],dtype=np.int64)
    train=splits=='train'; val=splits=='validation'
    if train.sum()<2 or val.sum()<1: raise ValueError('train/validation features missing')
    mean=X[train].mean(axis=0).astype(np.float32)
    std=X[train].std(axis=0).astype(np.float32)
    std=np.where(std<1e-6,1.0,std).astype(np.float32)
    Xn=((X-mean)/std).astype(np.float32)
    xt=torch.from_numpy(Xn[train]); yt=torch.from_numpy(y[train])
    xv=torch.from_numpy(Xn[val]); yv=torch.from_numpy(y[val])
    torch.manual_seed(args.seed)
    head=torch.nn.Linear(X.shape[1],len(classes))
    optimizer=torch.optim.AdamW(head.parameters(),lr=args.lr,weight_decay=args.weight_decay)
    loss_fn=torch.nn.CrossEntropyLoss()
    best_loss=math.inf; best_step=None; best_state=None; history=[]
    for step in range(1,args.steps+1):
        head.train()
        logits=head(xt); loss=loss_fn(logits,yt)
        optimizer.zero_grad(set_to_none=True); loss.backward(); optimizer.step()
        if step % 10 == 0 or step == args.steps:
            head.eval()
            with torch.inference_mode():
                v_logits=head(xv); v_loss=float(loss_fn(v_logits,yv))
                v_acc=float((v_logits.argmax(1)==yv).float().mean())
            history.append({'step':step,'train_loss':float(loss.detach()),'val_log_loss':v_loss,'val_accuracy':v_acc})
            if v_loss < best_loss:
                best_loss=v_loss; best_step=step
                best_state={k:v.detach().clone() for k,v in head.state_dict().items()}
    if best_state is None: raise RuntimeError('no probe checkpoint selected')
    head.load_state_dict(best_state); head.eval()
    val_probs=softmax_probs(head,xv)
    artifact=Path(artifact); artifact.mkdir(parents=True,exist_ok=True)
    weights=artifact/'adapter.safetensors'
    save_file({'head.weight':head.weight.detach().contiguous(),
        'head.bias':head.bias.detach().contiguous(),
        'feature_mean':torch.from_numpy(mean).contiguous(),
        'feature_std':torch.from_numpy(std).contiguous()},str(weights),metadata={'format':'pt'})
    # Harness supplies the manifest fields consumed by the transcribed inference runner.
    (artifact/'manifest.json').write_text(json.dumps({'class_order':classes,'classes':classes,'feature_dimension':int(X.shape[1])}))
    loaded=load_file(str(weights))
    reloaded=torch.nn.Linear(X.shape[1],len(classes))
    reloaded.load_state_dict({'weight':loaded['head.weight'],'bias':loaded['head.bias']},strict=True)
    reloaded.eval()
    mean2=loaded['feature_mean'].numpy(); std2=loaded['feature_std'].numpy()
    xv2=torch.from_numpy(((X[val]-mean2)/std2).astype(np.float32))
    val_probs_reloaded=softmax_probs(reloaded,xv2)
    max_diff=float(np.max(np.abs(val_probs_reloaded-val_probs)))
    if max_diff > 1e-6: raise RuntimeError(f'fresh reload probability mismatch: {max_diff}')
    return {'selected_step':best_step,'val_log_loss':best_loss,'reload_difference':max_diff,
        'history':history,'feature_mean':mean.tolist(),'class_order':classes}
