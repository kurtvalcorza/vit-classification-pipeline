# Image-classification notebook review probes

Reviewed repository: `kurtvalcorza/vit-classification-pipeline`  
Reviewed commit: `c92326be7b2754e7c00cf5cdb1c9a402cb3f16c7`  
Notebook blob: `c50a1eb660759c958b3f0cf20b66d86fae987ea9`  
Review date: 2026-09-27

## Evidence boundary

These are **offline source-excerpt reproductions**, not a copy of the full notebook, a Colab run, or tests of real pretrained vision features. Source was inspected through GitHub. Container network retrieval was unavailable, so relevant functions/runner logic were transcribed into small local files; this is not a byte-for-byte notebook-execution harness.

The fixtures are synthetic records, unique 8×8 PNG swatches, arbitrary 16×4 numeric feature matrices, and deliberately malformed prediction files. The common training/selection/normalization loop actually trains a small PyTorch linear classifier; the inference excerpt runs in separate Python processes and reads real SafeTensors files. **No MobileNet, ResNet, ConvNeXt, ViT, Swin, EVA or DINOv2 backbone is loaded.** No metrics here are bird-classification results.

`gallery_layout_synthetic.png` contains plain black image blocks and realistic class-name strings solely to reproduce text overlap. It is not a screenshot of the original Colab notebook or of a recorded model run.

## Files

- `source_excerpts.py`: acquisition/splitting, metrics and evaluator excerpts; imports/globals supplied by the harness.
- `train_loop_excerpt.py`: training/selection/serialization loop wrapped as a callable for synthetic feature fixtures. The harness creates a minimal manifest with the fields consumed by the inference runner; it does not claim to reproduce the full production artifact.
- `infer_probe_excerpt.py`: transcribed common inference runner.
- `run_probes.py`: fixtures, positive controls, fault-injection checks, and gallery-layout check.
- `results/probe_results.json`: observed results and complete local package inventory.
- `results/gallery_layout_synthetic.png`: internally inspected layout reproduction.

## Reproduce

Use an isolated Python environment with NumPy, pandas, Pillow, matplotlib, PyTorch and SafeTensors. The exact versions used for this review are recorded in `results/probe_results.json`. No model downloads are required.

```sh
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python run_probes.py
```

On Windows, set those environment variables with the equivalent shell syntax, then run `python run_probes.py`. Tests create a temporary workspace and overwrite only this package's `results/` outputs. GPU use is not required.

The assertions intentionally confirm the **reviewed revision's current behavior**, including defects. Passing this script is not a release acceptance test. To validate repairs, turn each demonstrated defect into a regression test against the **actual repaired notebook cells**, and require the corrected behavior instead. This script does not fetch or dynamically test later repository revisions.

## Probe inventory

1. Valid BYOD directory/ZIP acquisition; missing label rejection.
2. Six-class split counts and majority arithmetic on synthetic records.
3. Training-only normalization, bounded probe fitting, serialization/reload, and test inference on synthetic features.
4. Numeric, leading-zero and `NA` class labels accepted at acquisition but rejected during prediction scoring.
5. Two distinct 129-character labels collide in `U128` feature-label storage.
6. Missing difficult prediction improves the score without rejection.
7. Duplicate prediction ID, changed truth, and invalid probabilities are accepted by the evaluator.
8. Changed manifest class order bypasses the freeze assertions and changes decoded predictions.
9. Changed cached test features bypass the freeze assertions and change predictions.
10. Changed adapter bytes are rejected (positive control).
11. Shared-prefix training checkpoints match in a 300-vs-1000-step activity on the same synthetic features.
12. Whole-directory export includes old output on noncanonical workspace reuse; the notebook's fresh-runtime instruction avoids this case.
13. Error-gallery title overlap in the documented three-panel layout.

## Source references

Notebook: https://github.com/kurtvalcorza/vit-classification-pipeline/blob/c92326be7b2754e7c00cf5cdb1c9a402cb3f16c7/tutorials/DIMER_MultiModel_Image_Classification_Workshop.ipynb

Source cells: https://github.com/kurtvalcorza/vit-classification-pipeline/blob/c92326be7b2754e7c00cf5cdb1c9a402cb3f16c7/tools/multimodel_image_classification_workshop_source.py

The reviewed repository uses Apache-2.0. The quoted/transcribed source excerpts retain their original authorship; this review does not claim authorship of them.
