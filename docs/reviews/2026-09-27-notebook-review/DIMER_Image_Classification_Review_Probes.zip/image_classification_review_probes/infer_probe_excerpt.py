# Transcribed PROBE_INFER_RUNNER from pinned workshop source; no model-backbone call.
import argparse,csv,json
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import load_file

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--features",required=True)
    ap.add_argument("--artifact-dir",required=True)
    ap.add_argument("--split",required=True)
    ap.add_argument("--predictions",required=True)
    args=ap.parse_args()
    data=np.load(args.features,allow_pickle=False)
    X=data["features"].astype(np.float32)
    ids=data["ids"].astype(str); labels=data["labels"].astype(str); splits=data["splits"].astype(str)
    manifest=json.loads((Path(args.artifact_dir)/"manifest.json").read_text())
    classes=list(manifest["class_order"])
    selected=splits==args.split
    tensors=load_file(str(Path(args.artifact_dir)/"adapter.safetensors"))
    mean=tensors["feature_mean"].numpy(); std=tensors["feature_std"].numpy()
    x=torch.from_numpy(((X[selected]-mean)/std).astype(np.float32))
    head=torch.nn.Linear(X.shape[1],len(classes))
    head.load_state_dict({"weight":tensors["head.weight"],"bias":tensors["head.bias"]},strict=True)
    head.eval()
    with torch.inference_mode():
        probs=torch.softmax(head(x),dim=1).numpy()
    with open(args.predictions,"w",encoding="utf-8",newline="") as handle:
        fields=["id","truth","prediction",*[f"prob_{c}" for c in classes]]
        w=csv.DictWriter(handle,fieldnames=fields); w.writeheader()
        for rid,truth,p in zip(ids[selected],labels[selected],probs):
            row={"id":rid,"truth":truth,"prediction":classes[int(np.argmax(p))]}
            row.update({f"prob_{c}":float(p[i]) for i,c in enumerate(classes)})
            w.writerow(row)
if __name__=="__main__": main()
