# Probe results

Offline, transcribed source excerpts + synthetic fixtures. Not a full notebook or Colab run. No pretrained backbones.

| Check | Outcome |
|---|---|
| 01_BYOD_acquisition_positive_negative | PASS |
| 02_six_class_split_and_majority | PASS |
| 03_probe_training_and_reload | PASS |
| 04_BYOD_label_roundtrip | DEFECT_REPRODUCED |
| 05_fixed_width_label_collision | DEFECT_REPRODUCED |
| 06_missing_prediction | DEFECT_REPRODUCED |
| 07_prediction_integrity | DEFECT_REPRODUCED |
| 08_unbound_class_order | DEFECT_REPRODUCED |
| 09_unbound_feature_cache | DEFECT_REPRODUCED |
| 10_adapter_tamper_positive_control | PASS |
| 11_controlled_step_budget | PASS |
| 12_output_directory_reuse | RISK_REPRODUCED |
| 13_gallery_readability | DEFECT_REPRODUCED |
