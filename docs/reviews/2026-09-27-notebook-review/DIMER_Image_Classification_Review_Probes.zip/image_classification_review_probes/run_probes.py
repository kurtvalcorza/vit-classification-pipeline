"""Run bounded offline source-excerpt probes. See README for evidence limits.
No network; no pretrained backbones; all writes in a temporary directory or results/.
"""
from __future__ import annotations
import csv, hashlib, importlib.metadata, json, os, platform, shutil, subprocess, sys, tempfile, warnings, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
import torch
import source_excerpts as src
from train_loop_excerpt import run as train

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
torch.set_num_threads(1)
checks=[]
def add(name,status,**details):
    checks.append({'name':name,'status':status,**details})
def caught(fn):
    try: return {'accepted':True,'value':fn()}
    except Exception as e: return {'accepted':False,'error':f'{type(e).__name__}: {e}'}

def make_dataset(root,labels):
    root.mkdir()
    rows=[]
    for i in range(8*len(labels)):
        Image.new('RGB',(8,8),(i%256,(i*7)%256,(i*13)%256)).save(root/f'{i}.png')
        rows.append({'id':str(i),'file':f'{i}.png','label':labels[i//8]})
    pd.DataFrame(rows).to_csv(root/'labels.csv',index=False)
    return root

def make_features(path,labels=('alpha','beta')):
    # Arbitrary synthetic feature vectors, NOT image/model-derived representations.
    rng=np.random.default_rng(51)
    y=np.repeat(np.arange(2),8)
    X=np.repeat((y*2-1)[:,None],4,axis=1).astype(np.float32)+rng.normal(0,.05,(16,4)).astype(np.float32)
    splits=np.tile(['train']*5+['validation']+['test']*2,2)
    data={'features':X,'ids':np.array([f'image-{i}' for i in range(16)],dtype='U128'),
          'labels':np.array([labels[i] for i in y],dtype='U128'),'splits':splits.astype('U32')}
    np.savez_compressed(path,**data)
    return data

def infer(cache,art,out):
    env={**os.environ,'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','MPLBACKEND':'Agg'}
    p=subprocess.run([sys.executable,str(ROOT/'infer_probe_excerpt.py'),'--features',str(cache),
        '--artifact-dir',str(art),'--split','test','--predictions',str(out)],env=env,capture_output=True,text=True,timeout=25)
    if p.returncode: raise RuntimeError(p.stderr[-1500:])
    return pd.read_csv(out)

with tempfile.TemporaryDirectory(prefix='dimer-image-review-') as d:
    tmp=Path(d); src.WORK_ROOT=tmp/'work'; src.WORK_ROOT.mkdir()
    ds=make_dataset(tmp/'alpha',['alpha','beta']); rec=src.load_byod(ds)
    splits=src.stratified_byod_split(rec)
    assert {k:len(v) for k,v in splits.items()}=={'train':10,'validation':2,'test':4}
    assert len({src.decoded_pixel_digest(Path(x['path'])) for x in rec})==16
    archive=Path(shutil.make_archive(str(tmp/'alpha_archive'),'zip',root_dir=ds))
    assert len(src.load_byod(archive))==16
    # One genuinely malformed dataset should fail before training.
    bad=make_dataset(tmp/'bad',['alpha','beta'])
    df=pd.read_csv(bad/'labels.csv'); df.drop(columns='label').to_csv(bad/'labels.csv',index=False)
    invalid=caught(lambda:src.load_byod(bad)); assert not invalid['accepted']
    add('01_BYOD_acquisition_positive_negative','PASS',valid_directory_records=16,valid_zip_records=16,
        split_counts={k:len(v) for k,v in splits.items()},negative=invalid)

    six=[{'source_id':f'{c}-{i}','label':c} for c in 'abcdef' for i in range(30)]
    s=src.exact_builtin_split(six)
    m=src.basic_classification_metrics([x['label'] for x in s['validation']],['a']*24,list('abcdef'))
    assert [len(s[x]) for x in ['train','validation','test']]==[108,24,48]
    assert np.isclose(m['accuracy'],1/6) and np.isclose(m['macro_f1'],1/21)
    add('02_six_class_split_and_majority','PASS',fixture='synthetic records, not actual corpus photos',
        counts=[108,24,48],accuracy=m['accuracy'],macro_f1=m['macro_f1'])

    cache=tmp/'features.npz'; data=make_features(cache); art=tmp/'adapter'
    report=train(cache,art)
    pred=infer(cache,art,tmp/'test.csv'); _,metrics=src.evaluate_prediction_csv(tmp/'test.csv',['alpha','beta'])
    assert metrics['accuracy']==1.0 and report['reload_difference']==0
    assert np.allclose(report['feature_mean'],data['features'][data['splits']=='train'].mean(0))
    add('03_probe_training_and_reload','PASS',fixture='synthetic 16x4 feature matrix; no vision model',
        selected_step=report['selected_step'],validation_log_loss=report['val_log_loss'],
        reload_max_abs_difference=report['reload_difference'],test_accuracy=metrics['accuracy'],train_only_mean=True)

    label_cases=[]
    for slug,labels in [('numeric',['0','1']),('leading_zeros',['001','002']),('NA_token',['NA','other'])]:
        ds2=make_dataset(tmp/slug,labels); loaded=src.load_byod(ds2)
        cache2=tmp/f'{slug}.npz'; make_features(cache2,labels)
        art2=tmp/f'{slug}_art'; train(cache2,art2)
        out=tmp/f'{slug}.csv'; infer(cache2,art2,out)
        result=caught(lambda:src.evaluate_prediction_csv(out,labels)[1]['accuracy'])
        assert not result['accepted']
        label_cases.append({'labels':labels,'input_records_accepted':len(loaded),
             'after_csv_read_truth_dtype':str(pd.read_csv(out)['truth'].dtype),'evaluation':result})
    add('04_BYOD_label_roundtrip','DEFECT_REPRODUCED',cases=label_cases)

    long_labels=['species_'+'x'*120+'A','species_'+'x'*120+'B']
    ds3=make_dataset(tmp/'long',long_labels); accepted=src.load_byod(ds3)
    stored=np.asarray(long_labels,dtype='U128')
    assert len(set(long_labels))==2 and len(set(stored))==1
    add('05_fixed_width_label_collision','DEFECT_REPRODUCED',input_label_lengths=list(map(len,long_labels)),
        input_classes=2,feature_cache_classes=len(set(stored)),loader_accepted_records=len(accepted))

    classes=list('abcdef'); rows=[]
    for i in range(48):
        truth=classes[i//8]; chosen=truth if i!=0 else 'b'
        probs={f'prob_{c}':.95 if c==chosen else .01 for c in classes}
        rows.append({'id':f'test-{i:03d}','truth':truth,'prediction':chosen,**probs})
    df=pd.DataFrame(rows); p=tmp/'complete.csv'; df.to_csv(p,index=False)
    _,full=src.evaluate_prediction_csv(p,classes)
    df.iloc[1:].to_csv(tmp/'short.csv',index=False)
    _,short=src.evaluate_prediction_csv(tmp/'short.csv',classes)
    assert np.isclose(full['accuracy'],47/48) and short['accuracy']==1
    add('06_missing_prediction','DEFECT_REPRODUCED',complete_rows=48,complete_accuracy=full['accuracy'],
        missing_rows=47,missing_accuracy=short['accuracy'])

    duplicate=pd.concat([df.iloc[1:],df.iloc[[1]]],ignore_index=True)
    duplicate.to_csv(tmp/'duplicate.csv',index=False)
    _,dup=src.evaluate_prediction_csv(tmp/'duplicate.csv',classes)
    relabeled=df.copy(); relabeled.loc[0,'truth']='b'; relabeled.to_csv(tmp/'relabeled.csv',index=False)
    _,relab=src.evaluate_prediction_csv(tmp/'relabeled.csv',classes)
    bad_probs=df.copy(); bad_probs['prediction']=bad_probs['truth']
    for c in classes: bad_probs[f'prob_{c}']=2.0
    bad_probs.to_csv(tmp/'bad_probs.csv',index=False)
    _,prob=src.evaluate_prediction_csv(tmp/'bad_probs.csv',classes)
    assert dup['accuracy']==1 and relab['accuracy']==1 and prob['accuracy']==1 and prob['log_loss']==0
    add('07_prediction_integrity','DEFECT_REPRODUCED',same_count_duplicate_id_accuracy=dup['accuracy'],
        forged_truth_accuracy=relab['accuracy'],all_probabilities_2_accuracy=prob['accuracy'],
        all_probabilities_2_log_loss=prob['log_loss'])

    # Transcribed Section 14 identity checks; synthetic fixture supplies frozen metadata.
    frozen={'dataset':{'dataset_digest':'fixture-digest'},'core_models':['demo'],'dinov2_extension':False,
            'models':{'demo':{'revision':'fixture-revision','probe_artifact_sha256':src.sha256_file(art/'adapter.safetensors')}}}
    def check_freeze():
        dataset_digest='fixture-digest'; CORE_MODELS=['demo']; RUN_DINOV2_EXTENSION=False
        MODEL_SPECS={'demo':{'revision':'fixture-revision'}}; SELECTED_MODELS=['demo']
        frozen_loaded=frozen
        assert frozen_loaded['dataset']['dataset_digest']==dataset_digest
        assert frozen_loaded['core_models']==CORE_MODELS
        assert frozen_loaded['dinov2_extension']==RUN_DINOV2_EXTENSION
        for key in SELECTED_MODELS:
            assert frozen_loaded['models'][key]['revision']==MODEL_SPECS[key]['revision']
            assert frozen_loaded['models'][key]['probe_artifact_sha256']==src.sha256_file(art/'adapter.safetensors')
        return True
    manifest=json.loads((art/'manifest.json').read_text())
    manifest['class_order']=manifest['class_order'][::-1]
    (art/'manifest.json').write_text(json.dumps(manifest)); assert check_freeze()
    changed=infer(cache,art,tmp/'changed_order.csv')
    flips=int((changed['prediction']!=pred['prediction']).sum()); assert flips==4
    add('08_unbound_class_order','DEFECT_REPRODUCED',freeze_checks_pass=True,predictions_changed=flips,
        predictions_total=4,adapter_hash_unchanged=True)
    manifest['class_order']=manifest['class_order'][::-1]; (art/'manifest.json').write_text(json.dumps(manifest))
    altered={k:v.copy() for k,v in data.items()}; mask=altered['splits']=='test'
    altered['features'][mask]*=-1
    np.savez_compressed(cache,**altered); assert check_freeze()
    changed2=infer(cache,art,tmp/'changed_features.csv')
    flips2=int((changed2['prediction']!=pred['prediction']).sum()); assert flips2==4
    add('09_unbound_feature_cache','DEFECT_REPRODUCED',freeze_checks_pass=True,predictions_changed=flips2,predictions_total=4)
    original_weights=(art/'adapter.safetensors').read_bytes()
    (art/'adapter.safetensors').write_bytes(original_weights+b'x')
    assert not caught(check_freeze)['accepted']
    add('10_adapter_tamper_positive_control','PASS',modified_adapter_bytes_rejected=True)

    # Smaller-budget experiment checks the actual common training-loop trajectory, no backbones.
    np.savez_compressed(cache,**data)
    small=train(cache,tmp/'small_art',steps=300)
    assert report['history'][:30]==small['history']
    assert small['val_log_loss']>=report['val_log_loss']
    add('11_controlled_step_budget','PASS',fixture='same synthetic features, parameters and seed',
        shared_checkpoints_identical=True,budget_300_loss=small['val_log_loss'],budget_1000_loss=report['val_log_loss'])

    # Boundary matches the source export; fresh runtimes avoid this noncanonical-reuse case.
    output=tmp/'outputs'; (output/'test').mkdir(parents=True)
    (output/'test'/'eva.csv').write_text('old FULL result\n')
    (output/'test'/'vit.csv').write_text('current STANDARD result\n')
    (output/'summary.json').write_text(json.dumps({'tier':'STANDARD','models':['vit']}))
    bundle=shutil.make_archive(str(output.resolve())+'_DIMER_Image_Classification_Workshop_Report','zip',root_dir=output.resolve())
    names=zipfile.ZipFile(bundle).namelist(); assert 'test/eva.csv' in names
    add('12_output_directory_reuse','RISK_REPRODUCED',scope='noncanonical reuse; notebook instructs fresh runtime',archived_old_file=True)

    # Reconstruct the error-gallery layout with synthetic image blocks; no real image/model output.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    core=['mobilenet','resnet','convnext','vit']
    labs=['american_goldfinch','chipping_sparrow','dark_eyed_junco','house_finch','song_sparrow','white_throated_sparrow']
    titles=[]
    rules=['unanimous correct','unanimous wrong','largest disagreement']
    truths=[labs[0],labs[1],labs[-1]]
    predictions=[ [labs[0]]*4,[labs[-1]]*4,[labs[1],labs[2],labs[3],labs[4]]]
    fig,axes=plt.subplots(1,3,figsize=(15,5))
    for ax,rule,truth,pp in zip(axes,rules,truths,predictions):
        ax.imshow(np.zeros((8,8,3)))
        text=', '.join(f'{k}:{v}' for k,v in zip(core,pp))
        ax.set_title(f'{rule}\ntruth={truth}\n{text}',fontsize=9)
        ax.axis('off')
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always'); plt.tight_layout()
        layout_warnings=[str(x.message) for x in w]
    fig.canvas.draw(); rend=fig.canvas.get_renderer()
    boxes=[ax.title.get_window_extent(rend) for ax in axes]
    overlaps=[boxes[i].overlaps(boxes[i+1]) for i in range(2)]
    fig.savefig(OUT/'gallery_layout_synthetic.png',dpi=150,bbox_inches='tight')
    assert any(overlaps)
    add('13_gallery_readability','DEFECT_REPRODUCED',fixture='synthetic gallery, realistic built-in class names',
        adjacent_title_overlaps=overlaps,title_pixel_widths=[round(x.width,1) for x in boxes],
        axes_pixel_widths=[round(ax.get_window_extent(rend).width,1) for ax in axes],warnings=layout_warnings)
    plt.close(fig)

inventory={'python':platform.python_version(),'platform':platform.platform(),
           'packages':{p:importlib.metadata.version(p) for p in ['numpy','pandas','Pillow','matplotlib','torch','safetensors']}}
result={'reviewed_commit':'c92326be7b2754e7c00cf5cdb1c9a402cb3f16c7','environment':inventory,
        'boundary':'Offline, transcribed source excerpts + synthetic fixtures. Not a full notebook or Colab run. No pretrained backbones.',
        'checks':checks}
(OUT/'probe_results.json').write_text(json.dumps(result,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else str(x)))
print(json.dumps(result,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else str(x)))
