"""P1: fetch the 180 pinned iNaturalist photographs with the carried fetch_corpus (every file size- and
SHA-256-checked), rebuild the seed-42 108/24/48 split, check disjointness and observer overlap, and
recompute the majority floor with the carried metrics, to compare with the Kaggle record."""
import json, sys, types, importlib
from pathlib import Path
repo, out = Path(sys.argv[1]), Path(sys.argv[2])
pkg = types.ModuleType('vit_classification_pipeline'); pkg.__path__ = [str(repo / 'src/vit_classification_pipeline')]
sys.modules['vit_classification_pipeline'] = pkg
S = importlib.import_module('vit_classification_pipeline.samples')
M = importlib.import_module('vit_classification_pipeline.metrics')
files = S.fetch_corpus(cache_dir=str(out / 'inat'))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
classes = S.class_names(splits['train'])
floor = M.majority_baseline([r['label'] for r in splits['train']], [r['label'] for r in splits['test']], classes)
res = {'photographs': len(corpus), 'bytes': sum(len(v) for v in files.values()) if isinstance(files, dict) else None,
       'corpus_bytes_constant': S.CORPUS_BYTES, 'split': {k: len(v) for k, v in splits.items()},
       'disjoint': S.check_split_disjoint(splits), 'observer_overlap': S.observer_overlap(splits),
       'digests': {k: m['digest'][:8] for k, m in man.items()},
       'majority_floor': {'accuracy': round(floor['accuracy'], 4), 'macro_f1': round(floor['macro_f1'], 4)},
       'record_2026_09_19': {'majority_floor': {'accuracy': 0.1667, 'macro_f1': 0.0476}, 'digests_preflight': ['1e4cca7f', 'd176b3ff', '0e787f09'], 'observer_overlap_preflight': '31 of 117'}}
print(json.dumps(res, indent=1, default=str)); (out / 'p1.json').write_text(json.dumps(res, indent=1, default=str))
