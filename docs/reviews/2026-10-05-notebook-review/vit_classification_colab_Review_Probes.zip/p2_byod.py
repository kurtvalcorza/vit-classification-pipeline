"""P2: the BYOD contract. (a) load_byod_dataset + validate_dataset + split_dataset on constructed zips;
(b) the smallest balanced two-label set that split_dataset accepts, and the held-out test size it leaves;
(c) the accuracy the cell 17/21 asserts (selected accuracy > majority floor) then demand on that test split;
(d) cell 13's BYOD branch exec'd with a google.colab stand-in for a cancelled dialog, and outside Colab."""
import io, json, sys, types, zipfile, importlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('vit_classification_pipeline'); pkg.__path__ = [str(repo / 'src/vit_classification_pipeline')]
sys.modules['vit_classification_pipeline'] = pkg
S = importlib.import_module('vit_classification_pipeline.samples')
M = importlib.import_module('vit_classification_pipeline.metrics')
rng = np.random.default_rng(0)
def jpg():
    b = io.BytesIO(); Image.fromarray(rng.integers(0, 255, (48, 48, 3), dtype=np.uint8)).save(b, 'JPEG'); return b.getvalue()
def ok(n=10, prefix='', labels=('cat', 'dog')):
    rows = ['id,file,label'] + [f'r{i},img{i}.jpg,{labels[i % len(labels)]}' for i in range(n)]
    return {f'{prefix}labels.csv': '\n'.join(rows) + '\n', **{f'{prefix}img{i}.jpg': jpg() for i in range(n)}}
def zf(name, members):
    p = out / 'zips' / name; p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(p, 'w') as z:
        for k, v in members.items(): z.writestr(k, v)
    return p
cases = {
  'ok_16': ok(16), 'wrapping_folder_16': ok(16, 'mine/'),
  'missing_file': {k: v for k, v in ok(16).items() if k != 'img3.jpg'},
  'no_labels_csv': {k: v for k, v in ok(16).items() if k != 'labels.csv'},
  'one_label': ok(16, labels=('dog',)), 'seven_records': ok(7),
  'traversal_member': {**ok(16), '../evil.jpg': jpg()},
  'not_an_image': {**ok(16), 'img5.jpg': b'not a jpeg'},
}
res = {'a_loader': {}}
for name, members in cases.items():
    try:
        recs = S.load_byod_dataset(zf(name + '.zip', members)); S.validate_dataset(recs)
        sp = S.split_dataset(recs, seed=42)
        res['a_loader'][name] = {'accepted': True, 'split': {k: len(v) for k, v in sp.items()}}
    except Exception as exc:
        res['a_loader'][name] = {'accepted': False, 'error': f'{type(exc).__name__}: {exc}'[:200]}
sweep = {}
for n in range(8, 21):
    try:
        recs = S.load_byod_dataset(zf(f'n{n}.zip', ok(n)))
        sp = S.split_dataset(recs, seed=42)
        test = [r['label'] for r in sp['test']]
        fl = M.majority_baseline([r['label'] for r in sp['train']], test, S.class_names(sp['train']))
        need = min(k / len(test) for k in range(len(test) + 1) if k / len(test) > fl['accuracy'])
        sweep[n] = {'split': {k: len(v) for k, v in sp.items()}, 'floor_accuracy': round(fl['accuracy'], 3),
                    'min_test_accuracy_to_pass_assert': round(need, 3)}
    except Exception as exc:
        sweep[n] = {'refused': f'{type(exc).__name__}: {exc}'[:160]}
res['b_c_min_size_sweep'] = sweep
nb = json.loads((repo / 'tutorials/vit_classification_colab.ipynb').read_text())
c13 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
branch = c13.split('if USE_BYOD:\n', 1)[1].split('\nelse:', 1)[0]
branch = '\n'.join(l[4:] for l in branch.splitlines())
res['d_cell13_has_path_field'] = 'BYOD_PATH' in c13
for label, uploaded in {'cancelled_dialog': {}, 'two_files': {'a.zip': zf('a.zip', ok(16)).read_bytes(), 'b.txt': b'x'}}.items():
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda u=uploaded: dict(u))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {'Path': Path, 'load_byod_dataset': S.load_byod_dataset, 'split_dataset': S.split_dataset, 'SPLIT_SEED': 42}
    import os; os.chdir(out)
    try:
        exec(branch, g); res[f'd_{label}'] = {'outcome': 'accepted', 'used': g['file_name'], 'n': len(g['records'])}
    except BaseException as exc:
        res[f'd_{label}'] = {'outcome': f'{type(exc).__name__}: {exc}'[:160]}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
try:
    exec('from google.colab import files', {}); res['d_outside_colab'] = 'no error'
except Exception as exc:
    res['d_outside_colab'] = f'{type(exc).__name__}: {exc}'
print(json.dumps(res, indent=1, default=str)); (out / 'p2.json').write_text(json.dumps(res, indent=1, default=str))
